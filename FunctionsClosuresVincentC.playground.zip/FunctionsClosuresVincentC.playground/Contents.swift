//Critical Thinking

//Function to find percentage values
func findPercentValue(percent: Double, number: Double) -> String {
    let x = percent / 100
    let y = x * number
    return "\(percent)% of \(number) is \(y)"
}

print(findPercentValue(percent: 40, number: 750))


//Closure to find average of an Int array
var closureAverage = { (array: [Int] ) -> String in
    var count = 0
    var total = 0
    
    for i in array {
        count += 1
        total += i
    }
    let average = total / count
    return "the average of this sequence is \(average)."
}

print(closureAverage([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 55, 77, 112, 444, 555, 13, 67, 13, 14, 1444, 55, 102, 15]))
