//Critical thinking - collections

//Movies collection dictionary -- movie: release-year
var movies: [String: Int] = [
    "Avatar": 2009,
    "Grown Ups": 2010,
    "Step Brothers": 2008,
    "Ted": 2012,
    "Ted 2": 2015,
    "The Hangover": 2009,
    "The Hangover 2": 2011,
    "The Hangover 3": 2013,
    "The Other Guys": 2010,
    "30 Minutes or Less": 2011
]

//Array of movie releases before 2010
var beforeTwentyTen: [String] = []

//Looping to select pre-2010 movies releases
for (movie, date) in movies {
    if date < 2010 {
        beforeTwentyTen.append(movie)
    }
}

//Displaying movies released before 2010
print("Results: \(beforeTwentyTen.count)")
for i in beforeTwentyTen {
    print(i + " was released before 2010.")
}
