//Blackhawks lab

//10 Blackhawks players -- player: number
let blackHawksMembers: [String: Int] = [
    "Ryan Carpenter": 22,
    "Kirby Dach": 77,
    "Alex DeBrincat": 12,
    "Brandon Hagel": 38,
    "Mikael Hakkarainen": 59,
    "Matthew Highmore": 36,
    "Mattias Janmark": 13,
    "David Kampf": 64,
    "Patrick Kane": 88,
    "Dominik Kubalik": 8
]

//Ages of players
let playerAges: [Int] = [30, 20, 23, 22, 23, 25, 28, 26, 32, 25]

//Calculate total of player ages
var sumOfPlayerAges = 0
for age in playerAges {
    sumOfPlayerAges += age
}

//Average age
let averageAge = sumOfPlayerAges / playerAges.count
print("The average age of these players is \(averageAge).")

//Heights of players (inches)
let playerHeights: [Int] = [72, 76, 67, 71, 72, 71, 73, 74, 70, 74]

//Calculate total of player heights
var sumOfPlayerHeights = 0
for height in playerHeights {
    sumOfPlayerHeights += height
}

//Average height
let averageHeight = sumOfPlayerHeights / playerHeights.count
print("The average height of these players is \(averageHeight) inches.")

//Birth months of players
let playerBirthMonths: [String] = [
    "Jan", "Jan", "Dec", "Aug", "Jan", "Feb", "Dec",
    "Jan", "Nov", "Aug"
]

//Variable for count of each month
var countOfSep = 0
var countOfOct = 0
var countOfNov = 0
var countOfDec = 0
var countOfJan = 0
var countOfFeb = 0
var countOfMar = 0
var countOfApr = 0
var countOfMay = 0
var countOfJun = 0
var countOfJul = 0
var countOfAug = 0

//Control flow to decide which month is most common
for month in playerBirthMonths {
    if month == "Sep" {
        countOfSep += 1
    }
    else if month == "Oct" {
        countOfOct += 1
    }
    else if month == "Nov" {
        countOfNov += 1
    }
    else if month == "Dec" {
        countOfDec += 1
    }
    else if month == "Jan" {
        countOfJan += 1
    }
    else if month == "Feb" {
        countOfFeb += 1
    }
    else if month == "Mar" {
        countOfMar += 1
    }
    else if month == "Apr" {
        countOfApr += 1
    }
    else if month == "May" {
        countOfMay += 1
    }
    else if month == "Jun" {
        countOfJun += 1
    }
    else if month == "Jul" {
        countOfJul += 1
    }
    else {
        countOfAug += 1
    }
}

//Players with ages dictionary -- name: age
let playerWithAges: [String: Int] = [
    "Ryan Carpenter": 30,
    "Kirby Dach": 20,
    "Alex DeBrincat": 23,
    "Brandon Hagel": 22,
    "Mikael Hakkarainen": 23,
    "Matthew Highmore": 25,
    "Mattias Janmark": 28,
    "David Kampf": 26,
    "Patrick Kane": 32,
    "Dominik Kubalik": 25
]

//Player names and ages in ascending order
let playersSortedByAge = playerWithAges.sorted {$0.1 < $1.1 }
print(playersSortedByAge)

//Players with country dictionary -- name: country
let playerWithCountry: [String: String] = [
    "Ryan Carpenter": "USA",
    "Kirby Dach": "CAN",
    "Alex DeBrincat": "USA",
    "Brandon Hagel": "CAN",
    "Mikael Hakkarainen,": "FIN",
    "Matthew Highmore": "CAN",
    "Mattias Janmark": "SWE",
    "David Kampf": "CZE",
    "Patrick Kane": "USA",
    "Dominik Kubalik": "CZE"
]

//Player names and country in ascending order
let playersSortedByCountry = playerWithCountry.sorted {$0.1 < $1.1 }
print(playersSortedByCountry)
