//Critical thinking - ways to get to 100

//Arithmetic operators
//Adding
let add = 50 + 50
print(add)

//Subtracting
let subtract = 200 - 100
print(subtract)

//Multiplying
let multiply = 10 * 10
print(multiply)

//Dividing
let divide = 500 / 5
print(divide)

//Modulo
let modulo = 500 % 400
print(modulo)

//Compound assignment operators
//Adding
var addition = 40
addition += 60
print(addition)

//Subtracting
var subtraction = 500
subtraction -= 400
print(subtraction)

//Multiplying
var multiplication = 25
multiplication *= 4
print(multiplication)

//Dividing
var division = 1000
division /= 10
print(division)

//Modulo
var remain = 1000
remain %= 900

//Comparison operators
remain == 100
remain != 500
remain > 50
remain < 500
remain >= 100
remain <= 200
