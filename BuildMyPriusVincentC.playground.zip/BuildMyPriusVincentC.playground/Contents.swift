class customPrius
{
    //Initalized attribute values
    var model: String = "L Eco"
    var color: String = "Electric storm blue"
    var package: String = "Premium convienence package"
    var accessoryOne: String = "none"
    var accessoryTwo: String = "none"
    var accessoryThree: String = "none"
    
    //Setter & getter method for each attribute
    func setModel(modelChoice: String) {
        self.model = modelChoice
    }
    
    func getModel() {
        print("You have selected a model \(self.model)")
    }
    
    func setColor(colorChoice: String) {
        self.color = colorChoice
    }
    
    func getColor() {
        print("You have selected \(self.color) as your Prius color.")
    }
    
    func setPackage(packageChoice: String) {
        self.package = packageChoice
    }
    
    func getPackage() {
        print("You have selected \(self.package) as your package choice.")
    }
    
    func setAccessories(first: String, second: String, third: String) {
        self.accessoryOne = first
        self.accessoryTwo = second
        self.accessoryThree = third
    }

    func getAccessories() {
        print("You have selected \(self.accessoryOne), \(self.accessoryTwo), \(self.accessoryThree) as your accessories.")
    }
}

//Instance
var myPriusBuild = customPrius()

//Displaying model options
print("Model options:\n\nPrius L Eco\nPrius LE\nPrius XLE")
print("")

//Setting and getting choice selected
print("Hmmm, I want a Prius model LE.")
myPriusBuild.setModel(modelChoice: "LE")
myPriusBuild.getModel()

//Displaying color options
print("\nColor options:\n\nBlue\nRed\nPearl\nSilver\nGray\nBlack")
print("")

print("Hmmm, I want a gray Prius.")
myPriusBuild.setColor(colorChoice: "Gray")
myPriusBuild.getColor()

//Displaying package options
print("\nPackage options:\n\nPremium convenience package\nAdvanced technology package")
print("")

print("Hmmm, I want the premium convienence package.")
myPriusBuild.setPackage(packageChoice: "Premium convienence package")
myPriusBuild.getPackage()

//Displaying accessory options
print("\nAccessory options:\n\nHeated front seats\nHeated steering wheel\nCustom floor mats")
print("")

print("Hmmm, I want heated front seats, and a heated steering wheel.")

myPriusBuild.setAccessories(first: "Heated front seats", second: "Heated steering wheel", third: "")
myPriusBuild.getAccessories()
