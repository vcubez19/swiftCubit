//Fibonacci Lab

func fibonacci(number: Int) {
    var first = 0
    var second = 1
    
    print(first)
    while first < number {
        let fib = first
        first = second
        second += fib
        print(first)
    }
}

fibonacci(number: 1000)
