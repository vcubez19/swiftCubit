//Cookie shop sales -- constants & variables

//Constant cookie prices
let oatmealRaisin = 1.55
let chocolateChip = 2.55
let snickerDoodle = 4.77
let peanutButter = 4.15
let gingerBread = 5.45

//Variable sales total
var salesOfDay = 0.00

//Customer one
print("Hi, can I get two oatmeal raisins and three chocolate chips?")

//Employee does calculations
var customerOneTotal = (oatmealRaisin * 2) + (chocolateChip * 3)

//Employee gives customer total
print("That will be $\(customerOneTotal). Enjoy!")

//Customer one's total is added to the daily sales total
salesOfDay += customerOneTotal

//Customer two
print("Hi, can I get four ginger breads and two chocolate chips?")

//Employee does calculations
var customerTwoTotal = (gingerBread * 4) + (chocolateChip * 2)

//Employee tries to upsell
print("Do you want to add a snickerdoodle onto that? They're real good.")

//Customer response
print("Hmmm, add two snickerdoodles please.")

//Employee changes total
customerTwoTotal += snickerDoodle * 2

//Employee gives customer total
print("Your new total will be $\(customerTwoTotal). Enjoy!")

//Customer two's total is added to the daily sales total
salesOfDay += customerTwoTotal

//Employee's chatting
print("Wow, we've been open for five minutes and we already made $\(salesOfDay).")
print("We should've made chocolate chip more expensive halfway through the orders, they're a big hit!")
print("Well we can't, they're a constant.")
