//Clock App Recipe

//--The ingredients needed--

//A variable for each required time measurement
var hour = 1
var minute = 1
var second = 1

//--The directions to make this work--

/*
While hour is less than 24 hours -->
        contain the following in this loop

While minute is less 60 (hour)-->
        increment minute by 1 for each iteration that it less than 60
        when it is 60 increment the hour by 1

While second is less than 60 (minute)--
        increment second by 1 for each iteration that it less than 60
        when it is 60 increment the minute by 1
 
 Within the inner most loop print a statment to display the hour-minute-second
*/
