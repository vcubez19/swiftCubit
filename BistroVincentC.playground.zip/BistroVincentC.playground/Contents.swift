//Bistro enum
enum Bistro: CaseIterable {
    case Bacon
    case Beef
    case Salt
    case Pepper
    case Oil
    case Bun
    case Mustard
}

//Printing menu using enum
print("Menu options for the bistro burger:")

let str = String(repeating: "-", count: 35)
print(str)

for i in Bistro.allCases {
    print("\t\t\t", i)
}

//Struct to display my bistro
struct myBurger {
    var bacon: Bool
    var beef: Bool
    var salt: Bool
    var pepper: Bool
    var oil: Bool
    var bun: Bool
    var mustard: Bool
}

//Instance
var vinsBurger = myBurger(bacon: true, beef: true, salt: false, pepper: true, oil: true, bun: true, mustard: true)

//Optional initializing value to struct value
var vinHasBacon: Bool? = vinsBurger.bacon

print("")

//Optional binding
if let bacon = vinHasBacon {
    print("When asked if bacon, vin selected \(bacon).")
} else {
    print("vin already had bacon today.")
}
