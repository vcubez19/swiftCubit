//Variable for hour/minute/second
var hour = 1
var minute = 1
var second = 1

while hour < 5{
    while minute < 60{
        while second < 60{
            //Add 1 second each time through the seconds loop -- print exact time
            second += 1
            print("hour: \(hour) - minute: \(minute) - second: \(second)")
        }
        //Set second back to 0 when it has been a minute -- add 1 minute
        second = 0
        minute += 1
    }
    //Set minute back to 0 when it has been an hour -- add 1 hour
    minute = 0
    hour += 1
}
