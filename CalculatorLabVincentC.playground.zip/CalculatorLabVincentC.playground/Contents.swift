//calculator

//input
let zero = 0
let one = 1
let two = 2
let three = 3
let four = 4
let five = 5
let six = 6
let seven = 7
let eight = 8
let nine = 9

//operations
let addition = one + five
let subtraction = nine - seven
let multiplication = two * four
let division = nine / three
let percentage = (nine / three) * 100

//results
print("1 + 5 = \(addition)")
print("9 - 7 = \(subtraction)")
print("2 * 4 = \(multiplication)")
print("9 / 3 = \(division)")
print("nine is \(percentage)% of three.")

